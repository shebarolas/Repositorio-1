
package Utils;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileWriter;
import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;


public class ManejosDeArchivos {
    public static void crearDirectorio(String ruta){
        Path directorio = Paths.get(ruta);
        if(!Files.exists(directorio)){
            try{
                Files.createDirectories(directorio);
                System.out.println("El Directorio fue creado de forma exitosa");
            }catch(IOException e){
                System.out.println("El directorio no pudo ser creado");
            }
        }
    }

    public static void crearArchivo(String ruta, String datosAGuardar){
        Path directorio = Paths.get(ruta);
        String texto = datosAGuardar;
        try{
            Files.write(directorio, texto.getBytes());
            System.out.println("El archivo fue almacenado de forma exitosa");
        }catch(IOException e){
            System.out.println("El archivo fue no fue almacenado");
        }
    }

    public static void crearArchivoConcatenandoDatos(String ruta, String datos){
        Path directorio = Paths.get(ruta);
        FileWriter fw= null;
        BufferedWriter bw = null;
        try{
            File file = new File(ruta);
            if (!file.exists()) {
                file.createNewFile();
            }
            fw = new FileWriter(file.getAbsoluteFile(), true);
            bw = new BufferedWriter(fw);
            bw.write(datos);
            bw.newLine();
            System.out.println("Datos almacenados");
        }catch(Exception e){
            e.printStackTrace();
        }finally {
            try {
                if (bw != null)
                    bw.close();
                if (fw != null)
                    fw.close();
            } catch (IOException ex) {
                ex.printStackTrace();
            }
        }
    }

    public void verDatos(String ruta){
        Path archivo = Paths.get(ruta);
        String texto = "";
        try{
            texto = new String(Files.readAllBytes(archivo));

            String[] datos = texto.split("\\n");

            System.out.println(datos[0] + "\n"+datos[0]);
            System.out.println("Los datos son:");

            for (int i = 0; i < datos.length; i++){
                System.out.println((i+1)+".- "+datos[i].replace(";","\t"));
            }
            System.out.println();
        }catch(IOException e){
            System.out.println("El archivo no pudo ser leido");
        }

    }

    public static Object crearObjetoAPartirDeArchivo(int inicio, String ruta){
        Path archivo = Paths.get(ruta);
        String texto = "";

        Object obj = null;

        try{

            String atributo1 = "";
            int atributo2 = 0, atributo3 = 0;

            texto = new String(Files.readAllBytes(archivo));

            String[] linea = texto.split("\\n");

            for (int i = inicio; i < inicio+1; i++){
                String[] parametro = linea[i].split(";");

                for (int j = 0; j < parametro.length; j++){
                    switch (j){
                        case 0:
                            atributo1 = parametro[j];
                            break;
                        case 1:
                            atributo2 = Integer.parseInt(parametro[j]);
                            break;
                        case 2:
                            atributo3 = Integer.parseInt(parametro[j]);
                            break;
                    }

                }

            }
            //obj = new Object(atributo1, atributo2, atributo3);

        }catch(IOException e){
            System.out.println("El archivo no pudo ser leido");
        }
        return obj;
    }

    public static int cantidadDeLineas(String ruta){
        Path archivo = Paths.get(ruta);
        String texto = "";
        int cantidad = 0;
        try{
            texto = new String(Files.readAllBytes(archivo));
            String[] datos = texto.split("\\n");
            cantidad = datos.length;

        }catch(IOException e){
            System.out.println("El archivo no pudo ser evaluado");
        }
        return cantidad;
    }

}
