
package Utils;


public class Archivo {
    private String NOMBRE;
    private String DIRECTORIO;
    private String RUTA;

    public Archivo(String dir, String nombre) {
        this.NOMBRE = nombre;
        this.DIRECTORIO = dir;
        this.RUTA = this.DIRECTORIO + "/" + this.NOMBRE + ".txt";
    }

    public Archivo(String dic){
        this.NOMBRE = "";
        this.DIRECTORIO = dic;
        this.RUTA = this.DIRECTORIO;
    }

    public String getRUTA() {
        return RUTA;
    }

}
