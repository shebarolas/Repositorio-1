
package principal;
import Utils.Archivo;
import Utils.ManejosDeArchivos;

public class Principal extends ManejosDeArchivos {

    
    public static void main(String[] args) {
        Archivo directorio = new Archivo("probando");
        Archivo archivoTexto = new Archivo("probando", "salida");

        crearDirectorio(directorio.getRUTA());
        crearArchivo(archivoTexto.getRUTA(), "hola mundo!!");
        crearArchivoConcatenandoDatos(archivoTexto.getRUTA(), "texto agregado");



        for (int i = 0; i < cantidadDeLineas(archivoTexto.getRUTA()); i++){
            Object obj = crearObjetoAPartirDeArchivo(i, archivoTexto.getRUTA());
        }
    }

    }
    

