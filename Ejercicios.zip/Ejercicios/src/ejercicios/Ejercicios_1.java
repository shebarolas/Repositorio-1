
package ejercicios;


public class Ejercicios_1 {

    
    public static void main(String[] args) {
        int[][]matriz = new int[5][5];
        Matriz m = new Matriz();
        m.llenarMatriz(matriz);
        m.mostrarMatriz(matriz);
        System.out.println("Diagonal secuandaria");
        m.mostrarDiagonalSecundaria(matriz);
        System.out.println("Triangular superior");
        m.trinagularSuperior(matriz);
        System.out.println("Triangular inferior");
        m.triangularInferior(matriz);
    }
    
}
