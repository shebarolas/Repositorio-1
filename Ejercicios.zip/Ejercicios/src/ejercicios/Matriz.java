
package ejercicios;


public class Matriz {
    public void llenarMatriz(int matriz[][]){
        for (int i = 0; i < matriz.length; i++) {
            for (int j = 0; j < matriz.length; j++) {
                matriz[i][j]=NumerosAleatorios(1, 9);
            }
        }
    }
    
    public void mostrarMatriz(int matriz[][]){
        for (int i = 0; i < matriz.length; i++) {
            for (int j = 0; j < matriz.length; j++) {
                System.out.print("["+matriz[i][j]+"]");
            }
            System.out.println("");
        }
    }
    public void mostrarDiagonalSecundaria(int matriz[][]){
        for (int i = 0; i < matriz.length; i++) {
            for (int j = 0; j < matriz.length; j++) {
                if(i+j==matriz.length-1){
                    System.out.print("["+matriz[i][j]+"]");;
                }else{
                    System.out.print("[ ]");
                }
            }
            System.out.println("");
        }
    }
    public void trinagularSuperior(int matriz[][]){
        for (int i = 0; i < matriz.length; i++) {
            for (int j = 0; j < matriz.length; j++) {
                if(i+j<matriz.length-1){
                    System.out.print("["+matriz[i][j]+"]");
                }else{
                    System.out.print("[ ]");
                }
            }
            System.out.println("");
        }
    }
    public void triangularInferior(int matriz[][]){
        for (int i = 0; i < matriz.length; i++) {
            for (int j = 0; j < matriz.length; j++) {
                if(i+j>matriz.length-1){
                    System.out.print("["+matriz[i][j]+"]");
                }else{
                    System.out.print("[ ]");
                }
            }
            System.out.println("");
        }
    }
    public static int NumerosAleatorios(int maximo, int minimo){
        return (int)(Math.random()*10);
    }
}
